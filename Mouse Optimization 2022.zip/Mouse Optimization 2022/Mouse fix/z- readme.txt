Install The Reg File According To You Text Size 


Desktop > Display Settings > Scale And Layout
